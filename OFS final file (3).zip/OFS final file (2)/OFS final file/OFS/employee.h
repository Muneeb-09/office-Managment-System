#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <vector>
#include <fstream>
#include <cstring>

struct employee {
    int id;
    char name[100];
    char department[100];  // New field for department
    char role[100];
};

// Function declarations
void addEmployee(const employee& emp);
void removeEmployee(int empId);
std::vector<employee> fetchAllEmployees();

#endif // EMPLOYEE_H
