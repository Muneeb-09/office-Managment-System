#ifndef ITHEADDIALOG11_H
#define ITHEADDIALOG11_H

#include <QDialog>
#include "itheadpage.h"  // Include the header for itheadpage

namespace Ui {
class itheaddialog11;
}

class itheaddialog11 : public QDialog
{
    Q_OBJECT

public:
    explicit itheaddialog11(QWidget *parent = nullptr);
    ~itheaddialog11();

private slots:
    void onLoginButtonClicked();  // Slot for handling login button click
    void on_pushButtonLogin_2_clicked(); // Slot for handling cancel button click

private:
    Ui::itheaddialog11 *ui;  // Pointer to the generated UI

    itheadpage* itHeadPage;  // Pointer to the IT Head page
};

#endif // ITHEADDIALOG11_H
