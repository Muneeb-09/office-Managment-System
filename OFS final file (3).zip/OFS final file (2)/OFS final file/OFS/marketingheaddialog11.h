#ifndef MARKETINGHEADDIALOG11_H
#define MARKETINGHEADDIALOG11_H

#include <QDialog>
#include "marketingheadpage.h"

namespace Ui {
class marketingheaddialog11;
}

class marketingheaddialog11 : public QDialog
{
    Q_OBJECT

public:
    explicit marketingheaddialog11(QWidget *parent = nullptr);
    ~marketingheaddialog11();

private slots:
    void onLoginButtonClicked();  // Slot to handle the login button click

    void on_pushButtonLogin_2_clicked();

private:
    Ui::marketingheaddialog11 *ui;  // Pointer to the generated UI
    marketingheadpage* marketingHeadPage;  // Pointer to the IT Head page
};

#endif // MARKETINGHEADDIALOG11_H
