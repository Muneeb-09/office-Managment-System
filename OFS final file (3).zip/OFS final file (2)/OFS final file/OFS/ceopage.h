#ifndef CEOPAGE_H
#define CEOPAGE_H

#include <QMainWindow>
#include <QStandardItemModel>
#include <QTableView>
#include <QListWidgetItem>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QInputDialog>
#include <QPushButton>
#include <QDialog>
#include <fstream>
#include <vector>
#include <string>
#include <QDebug>

namespace Ui {
class ceopage;
}
//11
// Base class for Employee and Head
class EmployeeBase {
public:
    virtual void displayInfo() const = 0; // Pure virtual function
    virtual void writeToFile(std::ofstream& outFile) const = 0; // Pure virtual function for writing to file
    virtual void readFromFile(std::ifstream& inFile) = 0; // Pure virtual function for reading from file
    virtual ~EmployeeBase() {} // Virtual destructor
};

// Employee structure inheriting from EmployeeBase
struct Employee : public EmployeeBase {
    QString id;
    QString name;
    QString department;
    QString task;
    QString status;

    void displayInfo() const override {
        qDebug() << "Employee ID:" << id << "Name:" << name;
    }

    void writeToFile(std::ofstream& outFile) const override {
        size_t idSize = id.size();
        outFile.write(reinterpret_cast<const char*>(&idSize), sizeof(idSize));
        outFile.write(id.toStdString().c_str(), idSize);

        size_t nameSize = name.size();
        outFile.write(reinterpret_cast<const char*>(&nameSize), sizeof(nameSize));
        outFile.write(name.toStdString().c_str(), nameSize);

        size_t departmentSize = department.size();
        outFile.write(reinterpret_cast<const char*>(&departmentSize), sizeof(departmentSize));
        outFile.write(department.toStdString().c_str(), departmentSize);

        size_t taskSize = task.size();
        outFile.write(reinterpret_cast<const char*>(&taskSize), sizeof(taskSize));
        outFile.write(task.toStdString().c_str(), taskSize);

        size_t statusSize = status.size();
        outFile.write(reinterpret_cast<const char*>(&statusSize), sizeof(statusSize));
        outFile.write(status.toStdString().c_str(), statusSize);
    }

    void readFromFile(std::ifstream& inFile) override {
        size_t idSize;
        inFile.read(reinterpret_cast<char*>(&idSize), sizeof(idSize));
        char* idBuffer = new char[idSize + 1];
        inFile.read(idBuffer, idSize);
        idBuffer[idSize] = '\0';
        id = QString(idBuffer);
        delete[] idBuffer;

        size_t nameSize;
        inFile.read(reinterpret_cast<char*>(&nameSize), sizeof(nameSize));
        char* nameBuffer = new char[nameSize + 1];
        inFile.read(nameBuffer, nameSize);
        nameBuffer[nameSize] = '\0';
        name = QString(nameBuffer);
        delete[] nameBuffer;

        size_t departmentSize;
        inFile.read(reinterpret_cast<char*>(&departmentSize), sizeof(departmentSize));
        char* departmentBuffer = new char[departmentSize + 1];
        inFile.read(departmentBuffer, departmentSize);
        departmentBuffer[departmentSize] = '\0';
        department = QString(departmentBuffer);
        delete[] departmentBuffer;

        size_t taskSize;
        inFile.read(reinterpret_cast<char*>(&taskSize), sizeof(taskSize));
        char* taskBuffer = new char[taskSize + 1];
        inFile.read(taskBuffer, taskSize);
        taskBuffer[taskSize] = '\0';
        task = QString(taskBuffer);
        delete[] taskBuffer;

        size_t statusSize;
        inFile.read(reinterpret_cast<char*>(&statusSize), sizeof(statusSize));
        char* statusBuffer = new char[statusSize + 1];
        inFile.read(statusBuffer, statusSize);
        statusBuffer[statusSize] = '\0';
        status = QString(statusBuffer);
        delete[] statusBuffer;
    }
};

// Head structure inheriting from EmployeeBase
struct Head : public EmployeeBase {
    QString name;
    QString id;
    QString department;
    QString status;
    QString task;

    void displayInfo() const override {
        qDebug() << "Head ID:" << id << "Name:" << name;
    }

    void writeToFile(std::ofstream &outFile) const override {
        size_t nameSize = name.size();
        outFile.write(reinterpret_cast<const char*>(&nameSize), sizeof(nameSize));
        outFile.write(name.toStdString().c_str(), nameSize);
        size_t idSize = id.size();
        outFile.write(reinterpret_cast<const char*>(&idSize), sizeof(idSize));
        outFile.write(id.toStdString().c_str(), idSize);

        size_t departmentSize = department.size();
        outFile.write(reinterpret_cast<const char*>(&departmentSize), sizeof(departmentSize));
        outFile.write(department.toStdString().c_str(), departmentSize);

        size_t statusSize = status.size();
        outFile.write(reinterpret_cast<const char*>(&statusSize), sizeof(statusSize));
        outFile.write(status.toStdString().c_str(), statusSize);

        size_t taskSize = task.size();
        outFile.write(reinterpret_cast<const char*>(&taskSize), sizeof(taskSize));
        outFile.write(task.toStdString().c_str(), taskSize);
    }

    void readFromFile(std::ifstream &inFile) override {
        size_t nameSize;
        inFile.read(reinterpret_cast<char*>(&nameSize), sizeof(nameSize));
        char* nameBuffer = new char[nameSize + 1];
        inFile.read(nameBuffer, nameSize);
        nameBuffer[nameSize] = '\0';
        name = QString(nameBuffer);
        delete[] nameBuffer;

        size_t idSize;
        inFile.read(reinterpret_cast<char*>(&idSize), sizeof(idSize));
        char* idBuffer = new char[idSize + 1];
        inFile.read(idBuffer, idSize);
        idBuffer[idSize] = '\0';
        id = QString(idBuffer);
        delete[] idBuffer;

        size_t departmentSize;
        inFile.read(reinterpret_cast<char*>(&departmentSize), sizeof(departmentSize));
        char* departmentBuffer = new char[departmentSize + 1];
        inFile.read(departmentBuffer, departmentSize);
        departmentBuffer[departmentSize] = '\0';
        department = QString(departmentBuffer);
        delete[] departmentBuffer;

        size_t statusSize;
        inFile.read(reinterpret_cast<char*>(&statusSize), sizeof(statusSize));
        char* statusBuffer = new char[statusSize + 1];
        inFile.read(statusBuffer, statusSize);
        statusBuffer[statusSize] = '\0';
        status = QString(statusBuffer);
        delete[] statusBuffer;

        size_t taskSize;
        inFile.read(reinterpret_cast<char*>(&taskSize), sizeof(taskSize));
        char* taskBuffer = new char[taskSize + 1];
        inFile.read(taskBuffer, taskSize);
        taskBuffer[taskSize] = '\0';
        task = QString(taskBuffer);
        delete[] taskBuffer;
    }
};

class ceopage : public QMainWindow
{
    Q_OBJECT

public:
    explicit ceopage(QWidget *parent = nullptr);
    ~ceopage();

    // Getter for the employee model to share it with other parts of the application
    QStandardItemModel* getEmployeeModel();  // Accessor to the shared employee model

    // Setup the employee table and initialize the model
    void setupTable();
    void onAssignTaskClicked();
    void onSetDeadlineClicked();  // Add this line
    void onViewTaskClicked();

    void setupTable_2();
    void onViewTaskClicked_2();
    void loadEmployeesIntoTableView(QTableView* tableView, QStandardItemModel* model);

private slots:
    // Slots for button actions to switch pages
    void on_pushButtonEmployeeRecords_clicked();
    void on_pushButtonTaskMonitoring_clicked();
    void on_pushButtonHeadsManagement_clicked();

    // Slots for table operations
    void onAddEmployeeClicked();
    void onRemoveEmployeeClicked();
    void onUpdateTaskClicked();
    void onViewReportsClicked();

    // New slots added without modifying existing ones
    void onMarkTaskCompleteClicked();
    void onEditEmployeeDetailsClicked();
    void onExportDataClicked();
    void populateSampleData();  // Populate the table with initial data

    void onAddHeadClicked();   // Slot for adding a head
    void onRemoveHeadClicked(); // Slot for removing a selected head
    void on_pushButtonLogin_2_clicked();

private:
    Ui::ceopage *ui;  // UI pointer generated by Qt Designer

    // Shared model for storing employee records in a table
    QStandardItemModel *model;

    // Helper function to update the Task Monitoring Page with the current employee data
    void updateTaskMonitoringPage();

    // Additional helper methods
    void showTaskDetails(int row);  // Display task details for a selected employee
    void initializeHEADADDtableView(); // Declare the function here

    QStandardItemModel *headModel;    // Declare headModel as a class member
    QStandardItemModel *ceoModel;    // For CEO's employee data
    QStandardItemModel *itHeadModel; // For IT Head's employee data

    // Binary file handling functions
    void saveEmployeesToFile();
    void loadEmployeesFromFile();
    void saveHeadsToFile();
    void loadHeadsFromFile();
};

#endif // CEOPAGE_H
