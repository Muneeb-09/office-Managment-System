#include "marketingemployeepages.h"
#include "ui_marketingemployeepages.h"
#include <QMessageBox> // For error or success messages

marketingemployeepages::marketingemployeepages(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::marketingemployeepages)
{
    ui->setupUi(this);
    // Connect the Browse and Submit buttons to their respective slots
    connect(ui->marketingbrowseFileButton, &QPushButton::clicked, this, &marketingemployeepages::onBrowseFileClicked);
    connect(ui->marketingsubmitFileButton, &QPushButton::clicked, this, &marketingemployeepages::onSubmitFileClicked);

    // Optional: Initialize the table widget
    ui->marketinguploadedFilesTable->setColumnCount(1);
    ui->marketinguploadedFilesTable->setHorizontalHeaderLabels({"Uploaded Files"});
    ui->marketinguploadedFilesTable->horizontalHeader()->setStretchLastSection(true);
}

marketingemployeepages::~marketingemployeepages()
{
    delete ui;
}
// Slot for the Browse button
void marketingemployeepages::onBrowseFileClicked()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Select File to Upload", "", "All Files (*.*)");

    if (!filePath.isEmpty()) {
        ui->marketingfilePathLineEdit->setText(filePath); // Display the file path in the line edit
    }
}
// Slot for the Submit button
void marketingemployeepages::onSubmitFileClicked()
{
    QString filePath = ui->marketingfilePathLineEdit->text();

    if (filePath.isEmpty()) {
        QMessageBox::warning(this, "Error", "Please select a file to upload.");
        return;
    }

    // Define the upload directory
    QString uploadDir = "uploaded_files/";
    QDir dir;
    if (!dir.exists(uploadDir)) {
        dir.mkpath(uploadDir); // Create the directory if it doesn't exist
    }

    // Copy the file to the upload directory
    QFile file(filePath);
    QString fileName = QFileInfo(filePath).fileName();
    QString destination = uploadDir + fileName;

    if (file.copy(destination)) {
        QMessageBox::information(this, "Success", "File uploaded successfully!");
        ui->marketingfilePathLineEdit->clear(); // Clear the line edit
        updateUploadedFilesTable(fileName); // Update the table
    } else {
        QMessageBox::warning(this, "Error", "Failed to upload the file. Ensure the file is not open elsewhere.");
    }
}
// Update the table widget with the uploaded file
void marketingemployeepages::updateUploadedFilesTable(const QString &fileName)
{
    int row = ui->marketinguploadedFilesTable->rowCount();
    ui->marketinguploadedFilesTable->insertRow(row);

    QTableWidgetItem *fileItem = new QTableWidgetItem(fileName);
    ui->marketinguploadedFilesTable->setItem(row, 0, fileItem);
}

void marketingemployeepages::on_pushButtonLogin_2_clicked()
{
    this->close();
}

