#include "marketingheaddialog11.h"
#include "ui_marketingheaddialog11.h"  // Include the generated UI header
#include <QMessageBox>  // For showing message boxes

marketingheaddialog11::marketingheaddialog11(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::marketingheaddialog11)  // Allocate memory for the UI
{
    ui->setupUi(this);  // Setup the UI for this dialog

    // Connect the marketing login button to the slot
    connect(ui->pushButtonMarketingLogin, &QPushButton::clicked, this, &marketingheaddialog11::onLoginButtonClicked);

    // Connect the cancel button to reject the dialog
    connect(ui->pushButtonMarketingCancel, &QPushButton::clicked, this, &marketingheaddialog11::reject);
}

marketingheaddialog11::~marketingheaddialog11()
{
    delete ui;  // Clean up the UI object when the dialog is destroyed
    if (marketingHeadPage) {
        delete marketingHeadPage;  // Clean up IT Head page
    }
}

// Slot to handle the login button click
void marketingheaddialog11::onLoginButtonClicked()
{
    QString username = ui->lineEditMarketingUsername->text();  // Get the entered username
    QString password = ui->lineEditMarketingPassword->text();  // Get the entered password

    // Check if username and password fields are empty
    if (username.isEmpty() || password.isEmpty()) {
        return;  // Simply return if any field is empty, without showing a message box
    }

    // Correct credentials: username = "admin", password = "1234"
    QString correctUsername = "admin";
    QString correctPassword = "1234";

    // Check if entered username and password are correct
    if (username == correctUsername && password == correctPassword) {
        // Create and show the IT Head page
        marketingHeadPage = new marketingheadpage(this);  // Initialize the IT Head page
        marketingHeadPage->show();  // Show the IT Head page
    } else {
        // If credentials are incorrect
        QMessageBox::warning(this, "Login Error", "Invalid username or password!");
    }
}

void marketingheaddialog11::on_pushButtonLogin_2_clicked()
{
    this->close();
}

