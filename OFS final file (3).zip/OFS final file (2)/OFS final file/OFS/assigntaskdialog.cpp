#include "assigntaskdialog.h"
#include "ui_assigntaskdialog.h"
#include <QMessageBox>  // For showing messages

assigntaskdialog::assigntaskdialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::assigntaskdialog)
{
    ui->setupUi(this);

    // Set the Employee Name field as read-only
    ui->lineEditAssignedEmployee->setReadOnly(true);

    // Connect buttons to their respective slots
    connect(ui->pushButtonSaveTask, &QPushButton::clicked, this, &assigntaskdialog::onSaveTaskClicked);
    connect(ui->pushButtonAbortTask, &QPushButton::clicked, this, &assigntaskdialog::onCancelTaskClicked);
}

assigntaskdialog::~assigntaskdialog()
{
    delete ui;
}

// Function to set the Employee Name in the read-only field
void assigntaskdialog::setEmployeeName(const QString &name)
{
    ui->lineEditAssignedEmployee->setText(name);
}

void assigntaskdialog::onSaveTaskClicked()
{
    // Retrieve user inputs
    QString taskName = ui->lineEditTaskTitle->text();
    QString taskDescription = ui->textEditTaskDetails->toPlainText();
    QDate deadline = ui->dateEditTaskDueDate->date();
    QString employeeName = ui->lineEditAssignedEmployee->text();

    // Validate inputs
    if (taskName.isEmpty() || taskDescription.isEmpty() || employeeName.isEmpty()) {
        QMessageBox::warning(this, "Incomplete Data", "Please fill out all required fields.");
        return;
    }

    // Logic to save the task (e.g., send it to a database or add it to a model)
    // Here, we just display a message for now
    QMessageBox::information(this, "Task Assigned",
                             QString("Task '%1' has been assigned to %2.\nDeadline: %3")
                                 .arg(taskName, employeeName, deadline.toString("yyyy-MM-dd")));

    // Close the dialog after saving
    this->accept();
}

void assigntaskdialog::onCancelTaskClicked()
{
    // Close the dialog without saving
    this->reject();
}
