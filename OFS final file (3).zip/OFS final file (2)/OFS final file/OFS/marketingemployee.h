#ifndef MARKETINGEMPLOYEE_H
#define MARKETINGEMPLOYEE_H

class marketingEmployee
{
public:
    marketingEmployee();
};

#endif // MARKETINGEMPLOYEE_H
