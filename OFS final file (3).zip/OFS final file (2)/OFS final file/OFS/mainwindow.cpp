#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ceodialog11.h"
#include "marketingheaddialog11.h"
#include "itheaddialog11.h"
#include "itemployeedialog11.h"
#include "marketingemployeedialog.h"
#include "ceopage.h"
#include "assigntaskdialog.h"  // Include the Assign Task dialog header
#include <QMessageBox>
#include <QStandardItemModel>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    employeeModel(nullptr)  // Initialize employeeModel
{
    ui->setupUi(this);

    // Connect the OK button to the slot
    connect(ui->pushButtonOK, &QPushButton::clicked, this, &MainWindow::onOkButtonClicked);

    // Initialize Employee Table (Example)
    setupEmployeeTable();

    // Dynamically access ceopage widget inside MainWindow
    ceopage *page = this->findChild<ceopage*>("ceopage");  // Corrected to use pointer

    if (page) {
        QWidget *taskMonitoringPage = page->findChild<QWidget *>("TaskMonitoringPage");  // Find TaskMonitoringPage widget inside ceopage

        if (taskMonitoringPage) {
            // Find btnAssignTask button within TaskMonitoringPage
            QPushButton *btnAssignTask = taskMonitoringPage->findChild<QPushButton *>("btnAssignTask");

            if (btnAssignTask) {
                // Connect the Assign Task button to the corresponding slot
                connect(btnAssignTask, &QPushButton::clicked, this, &MainWindow::onAssignTaskClicked);
            } else {
                qDebug() << "Error: btnAssignTask not found!";
            }
        } else {
            qDebug() << "Error: TaskMonitoringPage not found!";
        }
    } else {
        qDebug() << "Error: ceopage not found!";
    }
}


MainWindow::~MainWindow()
{
     delete ui;
    delete employeeModel;  // Make sure to delete the model to avoid memory leaks
}

// Existing function for handling login logic
void MainWindow::onOkButtonClicked()
{
    if (ui->radioButtonCEO->isChecked()) {
        ceodialog11 dialog(this);
        if (dialog.exec() == QDialog::Accepted) {
            ceopage *page = new ceopage(this);
            page->show();
        } else {
            QMessageBox::warning(this, "Login", "CEO login canceled.");
        }
    }
    else if (ui->radioButtonMarketingDeptHead->isChecked()) {
        marketingheaddialog11 dialog(this);
        if (dialog.exec() == QDialog::Accepted) {
            QMessageBox::information(this, "Login", "Marketing Head login successful!");
        } else {
            QMessageBox::warning(this, "Login", "Marketing Head login canceled.");
        }
    }
    else if (ui->radioButtonITDeptHead->isChecked()) {
        itheaddialog11 dialog(this);
        if (dialog.exec() == QDialog::Accepted) {
            QMessageBox::information(this, "Login", "IT Head login successful!");
        } else {
            QMessageBox::warning(this, "Login", "IT Head login canceled.");
        }
    }
    else if (ui->radioButtonITDeptEmployee->isChecked()) {
        itemployeedialog11 dialog(this);
        if (dialog.exec() == QDialog::Accepted) {
            QMessageBox::information(this, "Login", "IT Employee login successful!");
        } else {
            QMessageBox::warning(this, "Login", "IT Employee login canceled.");
        }
    }
    else if (ui->radioButtonMarketingDeptEmployee->isChecked()) {
        marketingemployeedialog dialog(this);
        if (dialog.exec() == QDialog::Accepted) {
            QMessageBox::information(this, "Login", "Marketing Employee login successful!");
        } else {
            QMessageBox::warning(this, "Login", "Marketing Employee login canceled.");
        }
    }
    else {
        QMessageBox::warning(this, "Selection", "Please select an option first.");
    }
}

// Setup Employee Table with sample data
void MainWindow::setupEmployeeTable()
{
    // Initialize QStandardItemModel
    employeeModel = new QStandardItemModel(this);
    employeeModel->setColumnCount(4);  // Set column count
    employeeModel->setHeaderData(0, Qt::Horizontal, "ID");
    employeeModel->setHeaderData(1, Qt::Horizontal, "Name");
    employeeModel->setHeaderData(2, Qt::Horizontal, "Department");
    employeeModel->setHeaderData(3, Qt::Horizontal, "Role");

    // Add some dummy employee data
    employeeModel->appendRow({new QStandardItem("1"),
                              new QStandardItem("John Doe"),
                              new QStandardItem("Marketing"),
                              new QStandardItem("Manager")});
    employeeModel->appendRow({new QStandardItem("2"),
                              new QStandardItem("Jane Smith"),
                              new QStandardItem("IT"),
                              new QStandardItem("Developer")});
    employeeModel->appendRow({new QStandardItem("3"),
                              new QStandardItem("Emily Johnson"),
                              new QStandardItem("HR"),
                              new QStandardItem("Coordinator")});

    // Dynamically access the ceopage widget inside MainWindow
    ceopage *page = this->findChild<ceopage*>("ceopage");  // Corrected to use pointer

    if (page) {
        QWidget *taskMonitoringPage = page->findChild<QWidget *>("TaskMonitoringPage"); // Assuming TaskMonitoringPage is a QWidget

        if (taskMonitoringPage) {
            QTableView *tableView = taskMonitoringPage->findChild<QTableView *>("tableViewEmployeeRecords_2");  // Correct the name of the table view widget

            if (tableView) {
                // Link the model to table view
                tableView->setModel(employeeModel);
                tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
                tableView->setSelectionMode(QAbstractItemView::SingleSelection);
            } else {
                qDebug() << "Error: tableViewEmployeeRecords_2 not found!";
            }
        } else {
            qDebug() << "Error: TaskMonitoringPage not found!";
        }
    } else {
        qDebug() << "Error: ceopage not found!";
    }
}



// Handle Assign Task button click
void MainWindow::onAssignTaskClicked()
{
    // Access TaskMonitoringPage inside ceopage widget
    ceopage *page = this->findChild<ceopage*>("ceopage");  // Corrected to use pointer

    if (page) {
        QWidget *taskMonitoringPage = page->findChild<QWidget *>("TaskMonitoringPage");  // Find TaskMonitoringPage widget inside ceopage

        if (!taskMonitoringPage) {
            QMessageBox::warning(this, "Error", "TaskMonitoringPage not found.");
            return;
        }

        QTableView *tableView = taskMonitoringPage->findChild<QTableView *>("tableViewEmployeeRecords_2");  // Find table view widget inside TaskMonitoringPage

        if (!tableView) {
            QMessageBox::warning(this, "Error", "Table view not found in TaskMonitoringPage.");
            return;
        }

        // Check if an employee is selected
        QModelIndex currentIndex = tableView->selectionModel()->currentIndex();
        if (!currentIndex.isValid()) {
            QMessageBox::warning(this, "No Selection", "Please select an employee from the table.");
            return;
        }

        // Get the selected employee's name
        QString employeeName = employeeModel->index(currentIndex.row(), 1).data().toString();  // Assuming column 1 is Employee Name

        // Open the Assign Task dialog
        assigntaskdialog taskDialog(this);
        taskDialog.setEmployeeName(employeeName);  // Set employee name dynamically

        // Show dialog and handle result
        if (taskDialog.exec() == QDialog::Accepted) {
            QMessageBox::information(this, "Task Assigned", "The task has been successfully assigned.");
        } else {
            QMessageBox::information(this, "Task Canceled", "Task assignment was canceled.");
        }
    } else {
        QMessageBox::warning(this, "Error", "ceopage widget not found.");
    }
}


