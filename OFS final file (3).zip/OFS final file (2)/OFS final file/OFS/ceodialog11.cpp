#include "ceodialog11.h"
#include "ui_ceodialog11.h"
#include "ceopage.h"// Include the ceopage header to be able to create and show the page
#include "mainwindow.h"

ceodialog11::ceodialog11(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ceodialog11)
{
    ui->setupUi(this);

    // Connect the Login button to its slot
    connect(ui->pushButtonLogin, &QPushButton::clicked, this, &ceodialog11::onLoginButtonClicked);

    // Connect the Cancel button to its slot
    connect(ui->pushButtonCancel, &QPushButton::clicked, this, &ceodialog11::onCancelButtonClicked);
}

ceodialog11::~ceodialog11()
{
    delete ui;
}

void ceodialog11::onLoginButtonClicked()
{
    QString username = ui->lineEditUsername->text();
    QString password = ui->lineEditPassword->text();

    // Example validation logic
    if (username == "admin" && password == "1234") {
        // Create the CEO page (QMainWindow) and show it
        ceopage *page = new ceopage(this);  // Create the CEO page
        page->show();  // Display the CEO page

        accept(); // Close the dialog with success
        this->deleteLater(); // Ensure memory cleanup after showing the page
    } else {
        QMessageBox::warning(this, "Login", "Invalid username or password!");
    }
}

void ceodialog11::onCancelButtonClicked()
{
    reject(); // Close the dialog without action
    this->deleteLater();  // Clean up memory if dialog is canceled
}

void ceodialog11::on_pushButtonLogin_2_clicked()
{
    this->close();
}

