#ifndef TASKASSIGNMENTDIALOG_H
#define TASKASSIGNMENTDIALOG_H

#include <QDialog>

namespace Ui {
class TaskAssignmentDialog;
}

class TaskAssignmentDialog : public QDialog
{
    Q_OBJECT

public:
    explicit TaskAssignmentDialog(QWidget *parent = nullptr);
    ~TaskAssignmentDialog();

private slots:
    // Slot to handle when the submit button is clicked
    void on_submitButton_clicked();

private:
    Ui::TaskAssignmentDialog *ui;
};

#endif // TASKASSIGNMENTDIALOG_H
