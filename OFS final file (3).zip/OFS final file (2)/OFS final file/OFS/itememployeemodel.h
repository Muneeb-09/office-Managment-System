#ifndef ITEMEMPLOYEEMODEL_H
#define ITEMEMPLOYEEMODEL_H

#include <QAbstractTableModel>
#include <QFile>
#include <QTextStream>
#include <QList>

// ItemEmployee structure to represent employee information
class ItemEmployee {
public:
    QString name;
    QString employeeID;
    QString department;

    // Constructor
    ItemEmployee(const QString &name, const QString &employeeID, const QString &department)
        : name(name), employeeID(employeeID), department(department) {}
};

class ItemEmployeeModel : public QAbstractTableModel
{
    Q_OBJECT

public:
    explicit ItemEmployeeModel(QObject *parent = nullptr);
    ~ItemEmployeeModel();

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QVariant headerData(int section, Qt::Orientation orientation, int role) const override;

    void addEmployee(const ItemEmployee &employee);
    void removeEmployee(const QString &employeeID);  // Use employee ID to remove
    void loadDataFromFile();
    void saveDataToFile();

private:
    QList<ItemEmployee> employeeList;  // List to store employee information
};

#endif // ITEMEMPLOYEEMODEL_H
