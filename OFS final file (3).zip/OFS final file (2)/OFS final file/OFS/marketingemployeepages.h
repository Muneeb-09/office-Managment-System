#ifndef MARKETINGEMPLOYEEPAGES_H
#define MARKETINGEMPLOYEEPAGES_H

#include <QDialog>
#include <QFileDialog> // For file browsing
#include <QFile>       // For file handling
#include <QTableWidget> // For updating the uploaded files table

namespace Ui {
class marketingemployeepages;
}

class marketingemployeepages : public QDialog
{
    Q_OBJECT

public:
    explicit marketingemployeepages(QWidget *parent = nullptr);
    ~marketingemployeepages();
private slots:
    void onBrowseFileClicked();
    void onSubmitFileClicked();
    void on_pushButtonLogin_2_clicked();

private:
    Ui::marketingemployeepages *ui;
    void updateUploadedFilesTable(const QString &fileName); // To update the table with uploaded files
};

#endif // MARKETINGEMPLOYEEPAGES_H
