#include "itheadpage.h"
#include "ui_itheadpage.h"
#include <QStandardItemModel>
#include <QInputDialog>
#include <QMessageBox>
#include <QFile>
#include <QDataStream>

itheadpage::itheadpage(QDialog *parent) :
    QDialog(parent),
    ui(new Ui::itheadpage)
{
    ui->setupUi(this);

    // Initialize table view and set model
    employeeTable = ui->itheadpagecoffeetable;  // Assuming you have this table in your UI (.ui file)
    model = new QStandardItemModel(0, 4, this);  // 4 columns (Name, Department, ID, Task)
    employeeTable->setModel(model);

    // Set column headers
    model->setHorizontalHeaderLabels({"Name", "Department", "ID", "Task"});

    rowCount = 0;

    // Adjust column widths
    adjustTableColumns();

    // Connect buttons to their corresponding slots
    connect(ui->hiringofitemployee_pushbutton, &QPushButton::clicked, this, &itheadpage::onAddEmployeeClicked);
    connect(ui->firingofitemployee_pushbutton, &QPushButton::clicked, this, &itheadpage::onRemoveEmployeeClicked);
    connect(ui->assigningtasktoitemployee_pushbutton, &QPushButton::clicked, this, &itheadpage::onAssignTaskClicked);
    connect(ui->checkingtaskofitemployee_pushbutton, &QPushButton::clicked, this, &itheadpage::onViewTaskClicked);

    employeeTable->setSelectionMode(QAbstractItemView::SingleSelection);
    employeeTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    // Load saved employee data from the binary file
    loadEmployeeData();
}

itheadpage::~itheadpage()
{
    // Save data before closing
    saveEmployeeData();
    delete ui;
}

// Slot for adding a new employee
void itheadpage::onAddEmployeeClicked()
{
    bool ok;
    QString name = QInputDialog::getText(this, "Add Employee", "Enter employee name:", QLineEdit::Normal, "", &ok);
    if (ok && !name.isEmpty()) {
        QString department = QInputDialog::getText(this, "Add Employee", "Enter employee department:", QLineEdit::Normal, "", &ok);
        if (ok && !department.isEmpty()) {
            int id = QInputDialog::getInt(this, "Add Employee", "Enter employee ID:", 0, 0, 100000, 1, &ok);
            if (ok) {
                // Add the employee to the model
                QList<QStandardItem *> items;
                items.append(new QStandardItem(name));
                items.append(new QStandardItem(department));
                items.append(new QStandardItem(QString::number(id)));
                items.append(new QStandardItem(""));  // Empty task for new employee

                model->appendRow(items);
                rowCount++;
            }
        }
    }
}

// Slot for removing an employee
void itheadpage::onRemoveEmployeeClicked()
{
    QItemSelectionModel *select = employeeTable->selectionModel();
    QModelIndexList selectedRows = select->selectedRows();

    if (!selectedRows.isEmpty()) {
        for (const QModelIndex &index : selectedRows) {
            model->removeRow(index.row());
        }
        rowCount--;
    } else {
        QMessageBox::warning(this, "Error", "Please select an employee to fire.");
    }
}

// Slot for assigning a task to an employee
void itheadpage::onAssignTaskClicked()
{
    QItemSelectionModel *select = employeeTable->selectionModel();
    QModelIndexList selectedRows = select->selectedRows();

    if (!selectedRows.isEmpty()) {
        bool ok;
        QString task = QInputDialog::getText(this, "Assign Task", "Enter task for the selected employee:", QLineEdit::Normal, "", &ok);
        if (ok && !task.isEmpty()) {
            // Assign task in the last column (Task column)
            int row = selectedRows.first().row();
            model->setData(model->index(row, 3), task);  // Set task in the fourth column
        }
    } else {
        QMessageBox::warning(this, "Error", "Please select an employee to assign a task.");
    }
}

// Slot for viewing an employee's task
void itheadpage::onViewTaskClicked()
{
    QItemSelectionModel *select = employeeTable->selectionModel();
    QModelIndexList selectedRows = select->selectedRows();

    if (!selectedRows.isEmpty()) {
        int row = selectedRows.first().row();
        QString task = model->data(model->index(row, 3)).toString();
        task = task.isEmpty() ? "No task assigned" : task;
        QMessageBox::information(this, "Employee Task", "Task: " + task);
    } else {
        QMessageBox::warning(this, "Error", "Please select an employee to view the task.");
    }
}

// Helper function to initialize the table columns
void itheadpage::adjustTableColumns()
{
    employeeTable->setColumnWidth(0, 180);  // Set width of Name column
    employeeTable->setColumnWidth(1, 180);  // Set width of Department column
    employeeTable->setColumnWidth(2, 180);  // Set width of ID column
    employeeTable->setColumnWidth(3, 180);  // Set width of Task column
}

// Save employee data to a binary file
void itheadpage::saveEmployeeData()
{
    QFile file("employeeData.dat");
    if (file.open(QIODevice::WriteOnly)) {
        QDataStream out(&file);
        out << rowCount;  // Store the number of employees

        for (int i = 0; i < rowCount; ++i) {
            QString name = model->data(model->index(i, 0)).toString();
            QString department = model->data(model->index(i, 1)).toString();
            int id = model->data(model->index(i, 2)).toInt();
            QString task = model->data(model->index(i, 3)).toString();
            out << name << department << id << task;
        }
        file.close();
    } else {
        QMessageBox::warning(this, "Error", "Failed to save employee data.");
    }
}

// Load employee data from a binary file
void itheadpage::loadEmployeeData()
{
    QFile file("employeeData.dat");
    if (file.open(QIODevice::ReadOnly)) {
        QDataStream in(&file);
        int employeeCount;
        in >> employeeCount;  // Read the number of employees
        rowCount = employeeCount;  // Set rowCount to the number of employees

        for (int i = 0; i < employeeCount; ++i) {
            QString name, department, task;
            int id;
            in >> name >> department >> id >> task;
            QList<QStandardItem *> items;
            items.append(new QStandardItem(name));
            items.append(new QStandardItem(department));
            items.append(new QStandardItem(QString::number(id)));
            items.append(new QStandardItem(task));

            model->appendRow(items);
        }
        file.close();
    } else {
        QMessageBox::warning(this, "Error", "Failed to load employee data.");
    }
}


void itheadpage::on_pushButtonLogin_2_clicked()
{
    this->close();
}

