#ifndef ITHEADPAGE_H
#define ITHEADPAGE_H

#include <QDialog>
#include <QTableView>
#include <QStandardItemModel>
#include <QPushButton>

namespace Ui {
class itheadpage;
}

class itheadpage : public QDialog
{
    Q_OBJECT

public:
    explicit itheadpage(QDialog *parent = nullptr);
    ~itheadpage();

private slots:
    void onAddEmployeeClicked();
    void onRemoveEmployeeClicked();
    void onAssignTaskClicked();
    void onViewTaskClicked();

    void on_pushButtonLogin_2_clicked();

private:
    void adjustTableColumns();
    void saveEmployeeData();
    void loadEmployeeData();

    Ui::itheadpage *ui;
    QTableView *employeeTable;
    QStandardItemModel *model;
    int rowCount;

};

#endif // ITHEADPAGE_H
