#include "ceo.h" // Include the header file
#include "ui_ceologindialog.h" // Include the generated UI header file
#include <QMessageBox> // Include QMessageBox for dialog popups

// Constructor: Initializes the UI and connects signals
CeoLoginDialog::CeoLoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CeoLoginDialog)
{
    ui->setupUi(this); // Set up the UI components

    // Connect the login button signal to the onLoginClicked slot
    connect(ui->loginButton, &QPushButton::clicked, this, &CeoLoginDialog::onLoginClicked);
}

// Destructor: Deletes the UI
CeoLoginDialog::~CeoLoginDialog()
{
    delete ui; // Free the allocated memory
}

// Slot: Handles login button click logic
void CeoLoginDialog::onLoginClicked()
{
    QString username = ui->usernameEdit->text(); // Get the text from the username input
    QString password = ui->passwordEdit->text(); // Get the text from the password input

    // Validate the username and password
    if (username == "admin" && password == "admin")
    {
        QMessageBox::information(this, "Login", "Welcome CEO!"); // Success message
        accept(); // Close the dialog and indicate success
    }
    else
    {
        QMessageBox::critical(this, "Login Error", "Incorrect username or password."); // Error message
    }
}
