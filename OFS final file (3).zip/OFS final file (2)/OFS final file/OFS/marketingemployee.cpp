#include "marketingemployee.h"

marketingEmployee::marketingEmployee() {}
