#ifndef ITEMLOYEEPAGES_H
#define ITEMLOYEEPAGES_H

#include <QDialog>
#include <QFileDialog> // For file browsing
#include <QFile>       // For file handling
#include <QTableWidget> // For updating the uploaded files table
//#include <QDir>

namespace Ui {
class itemployeepages;
}

class itemployeepages : public QDialog
{
    Q_OBJECT

public:
    explicit itemployeepages(QWidget *parent = nullptr);
    ~itemployeepages();

private slots:
    void onBrowseFileClicked();
    void onSubmitFileClicked();

    void on_pushButtonLogin_2_clicked();

private:
    Ui::itemployeepages *ui;
    void updateUploadedFilesTable(const QString &fileName); // To update the table with uploaded files
    // void saveUploadedFiles();        // Save file list to persistent storage
    // void loadUploadedFiles();        // Load file list from persistent storage
    // const QString fileDataPath = "uploadedFilesData.txt"; // File to store file names
};

#endif // ITEMLOYEEPAGES_H
