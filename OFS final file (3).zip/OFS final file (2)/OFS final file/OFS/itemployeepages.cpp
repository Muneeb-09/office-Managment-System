#include "itemployeepages.h"
#include "ui_itemployeepages.h"
#include <QMessageBox> // For error or success messages

itemployeepages::itemployeepages(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::itemployeepages)
{
    ui->setupUi(this);

    // Connect the Browse and Submit buttons to their respective slots
    connect(ui->browseFileButton, &QPushButton::clicked, this, &itemployeepages::onBrowseFileClicked);
    connect(ui->submitFileButton, &QPushButton::clicked, this, &itemployeepages::onSubmitFileClicked);

    // Optional: Initialize the table widget
    ui->uploadedFilesTable->setColumnCount(1);
    ui->uploadedFilesTable->setHorizontalHeaderLabels({"Uploaded Files"});
    ui->uploadedFilesTable->horizontalHeader()->setStretchLastSection(true);
}

itemployeepages::~itemployeepages()
{
    delete ui;
}

// Slot for the Browse button
void itemployeepages::onBrowseFileClicked()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Select File to Upload", "", "All Files (*.*)");

    if (!filePath.isEmpty()) {
        ui->filePathLineEdit->setText(filePath); // Display the file path in the line edit
    }
}

// Slot for the Submit button
void itemployeepages::onSubmitFileClicked()
{
    QString filePath = ui->filePathLineEdit->text();

    if (filePath.isEmpty()) {
        QMessageBox::warning(this, "Error", "Please select a file to upload.");
        return;
    }

    // Define the upload directory
    QString uploadDir = "uploaded_files/";
    QDir dir;
    if (!dir.exists(uploadDir)) {
        dir.mkpath(uploadDir); // Create the directory if it doesn't exist
    }

    // Copy the file to the upload directory
    QFile file(filePath);
    QString fileName = QFileInfo(filePath).fileName();
    QString destination = uploadDir + fileName;

    if (file.copy(destination)) {
        QMessageBox::information(this, "Success", "File uploaded successfully!");
        ui->filePathLineEdit->clear(); // Clear the line edit
        updateUploadedFilesTable(fileName); // Update the table
    } else {
        QMessageBox::warning(this, "Error", "Failed to upload the file. Ensure the file is not open elsewhere.");
    }
}

// Update the table widget with the uploaded file
void itemployeepages::updateUploadedFilesTable(const QString &fileName)
{
    int row = ui->uploadedFilesTable->rowCount();
    ui->uploadedFilesTable->insertRow(row);

    QTableWidgetItem *fileItem = new QTableWidgetItem(fileName);
    ui->uploadedFilesTable->setItem(row, 0, fileItem);
}

void itemployeepages::on_pushButtonLogin_2_clicked()
{
    this->close();
}

