#include "ceopage.h"
#include "ui_ceopage.h"
#include <QStandardItemModel>
#include <QStandardItem>
#include <QMessageBox>
#include <QInputDialog>  // For input dialogs
#include "assigntaskdialog.h"  // Include the dialog header for task assignment
#include <QTimer>
#include <fstream>  // for file operations

ceopage::ceopage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ceopage),
    model(new QStandardItemModel(this)),
    headModel(new QStandardItemModel(this)),
    ceoModel(new QStandardItemModel(this)),
    itHeadModel(new QStandardItemModel(this))
{
    ui->setupUi(this);
    setupTable(); // Set up the employee records table

    qDebug() << "ceopage constructor called";  // Log initialization

    // Connect buttons to switch pages in QStackedWidget
    connect(ui->pushButtonEmployeeRecords, &QPushButton::clicked, this, &ceopage::on_pushButtonEmployeeRecords_clicked);
    connect(ui->pushButtonTaskMonitoring, &QPushButton::clicked, this, &ceopage::on_pushButtonTaskMonitoring_clicked);
    connect(ui->pushButtonHeadsManagement, &QPushButton::clicked, this, &ceopage::on_pushButtonHeadsManagement_clicked);

    // Connect table management buttons to their respective slots
    connect(ui->pushButtonAddEmployee_2, &QPushButton::clicked, this, &ceopage::onAddEmployeeClicked);
    connect(ui->pushButtonRemoveEmployee_2, &QPushButton::clicked, this, &ceopage::onRemoveEmployeeClicked);
    connect(ui->pushButtonUpdateTask_2, &QPushButton::clicked, this, &ceopage::onUpdateTaskClicked);
    connect(ui->pushButtonViewReports_2, &QPushButton::clicked, this, &ceopage::onViewReportsClicked);

    // Connect the "Assign Task" button in Task Monitoring Page
    connect(ui->btnAssignTask, &QPushButton::clicked, this, &ceopage::onAssignTaskClicked);

    // Connect the Set Deadline and View Task buttons
    connect(ui->btnSetDeadline, &QPushButton::clicked, this, &ceopage::onSetDeadlineClicked);
    connect(ui->btnViewTask, &QPushButton::clicked, this, &ceopage::onViewTaskClicked);

    connect(ui->HEADADDpushButton, &QPushButton::clicked, this, &ceopage::onAddHeadClicked);
    connect(ui->REMOVEHEADpushButton, &QPushButton::clicked, this, &ceopage::onRemoveHeadClicked);
    // Additional setup for new features
    populateSampleData(); // Populate the table with sample data
    // Initialize the HEADADDtableView
    initializeHEADADDtableView();
    loadEmployeesFromFile();
    loadHeadsFromFile(); // Load head data from file
}

ceopage::~ceopage()
{
    saveEmployeesToFile();  // Save employees data when closing the application
    saveHeadsToFile();
    delete ui;
}

void ceopage::setupTable() {
    // Initialize QStandardItemModel for employee records
    model = new QStandardItemModel(this);
    model->setColumnCount(5);
    model->setHeaderData(0, Qt::Horizontal, "ID");
    model->setHeaderData(1, Qt::Horizontal, "Name");
    model->setHeaderData(2, Qt::Horizontal, "Department");
    model->setHeaderData(3, Qt::Horizontal, "Role");
    model->setHeaderData(4, Qt::Horizontal, "Status");

    // Assuming you have a QTableView in your layout:
    QTableView *tableView = findChild<QTableView *>("tableViewEmployeeRecords");
    if (tableView) {
        tableView->setModel(model);
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableView->setSelectionMode(QAbstractItemView::SingleSelection);

        // Set custom column widths (increase to make them more visible)
        tableView->setColumnWidth(0, 160);  // Employee ID column width
        tableView->setColumnWidth(1, 160);  // Employee Name column width
        tableView->setColumnWidth(2, 160);  // Department column width
        tableView->setColumnWidth(3, 160);  // Role column width
        tableView->setColumnWidth(4, 160);  // Task Status column width
    }
}

// Slots for navigation buttons
void ceopage::on_pushButtonEmployeeRecords_clicked()
{
    ui->stackedWidget->setCurrentIndex(0); // Switch to Employee Records page
}

void ceopage::on_pushButtonTaskMonitoring_clicked()
{
    ui->stackedWidget->setCurrentIndex(1); // Switch to Task Monitoring page
    updateTaskMonitoringPage(); // Ensure Task Monitoring Page has updated data
}

void ceopage::on_pushButtonHeadsManagement_clicked()
{
    ui->stackedWidget->setCurrentIndex(2); // Switch to Heads Management page
}

// Update Task Monitoring Page with employee data
void ceopage::onRemoveEmployeeClicked() {
    // Example: Show a confirmation dialog or delete the selected employee
    QModelIndex index = ui->tableViewEmployeeRecords->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Employee Selected", "Please select an employee to remove.");
        return;
    }

    // Confirm employee removal
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Remove Employee", "Are you sure you want to remove this employee?",
                                  QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        model->removeRow(index.row());  // Remove the selected employee
    }
}

void ceopage::updateTaskMonitoringPage() {
    QTableView *taskMonitoringTable = findChild<QTableView *>("tableViewEmployeeRecords_2");
    if (taskMonitoringTable) {
        taskMonitoringTable->setModel(model);  // Ensure the model is set here
        taskMonitoringTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        taskMonitoringTable->setSelectionMode(QAbstractItemView::SingleSelection);

        // Ensure that the table allows editing
        taskMonitoringTable->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);
        // Set custom column widths for the Task Monitoring page
        taskMonitoringTable->setColumnWidth(0, 155);  // Employee ID column width
        taskMonitoringTable->setColumnWidth(1, 155);  // Employee Name column width
        taskMonitoringTable->setColumnWidth(2, 155);  // Department column width
        taskMonitoringTable->setColumnWidth(3, 155);  // Role column width
        taskMonitoringTable->setColumnWidth(4, 155);  // Task Status column width
    } else {
        QMessageBox::warning(this, "Error", "Task Monitoring Table not found.");
    }
}

// Open the AssignTaskDialog when the "Assign Task" button is clicked
void ceopage::onAssignTaskClicked() { //repeated
    // Find the selected employee from the table (or however you're managing employee selection)
    QModelIndex index = ui->tableViewEmployeeRecords_2->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Employee Selected", "Please select an employee to assign a task.");
        return;
    }

    // Get the employee name (or any other relevant data) from the selected row
    QString employeeName = model->data(model->index(index.row(), 1)).toString();  // Assuming employee name is in the 2nd column

    // Create and show the AssignTaskDialog
    assigntaskdialog *dialog = new assigntaskdialog(this);  // Using the correct dialog class name
    dialog->setEmployeeName(employeeName);  // Set the employee name in the dialog
    dialog->exec();  // Show the dialog as a modal window
}

// Slot for Set Deadline Button
void ceopage::onSetDeadlineClicked() {
    QModelIndex index = ui->tableViewEmployeeRecords_2->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Employee Selected", "Please select an employee to assign a deadline.");
        return;
    }

    // Get the task from the selected row (assuming it's in the 4th column)
    QString task = model->data(model->index(index.row(), 3)).toString();

    bool ok;
    QString deadline = QInputDialog::getText(this, "Set Deadline", "Enter the deadline for the task:", QLineEdit::Normal, "", &ok);
    if (ok && !deadline.isEmpty()) {
        model->setData(model->index(index.row(), 4), deadline);  // Set the deadline in the Task Status column
    }
}

// Slot for View Task Button
void ceopage::onViewTaskClicked() { //repeated
    QModelIndex index = ui->tableViewEmployeeRecords_2->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Employee Selected", "Please select an employee to view the task.");
        return;
    }

    // Get the task from the selected row (assuming it's in the 4th column)
    QString task = model->data(model->index(index.row(), 3)).toString();  // Task is in 4th column

    QMessageBox::information(this, "Task Details", "Task for " + model->data(model->index(index.row(), 1)).toString() + ": " + task);
}

// Slots for table operations (Add, Remove, Update, etc.)
void ceopage::onAddEmployeeClicked()
{
    bool ok;  // Validation status

    QString id = QInputDialog::getText(this, "Employee ID", "Enter Employee ID:", QLineEdit::Normal, "", &ok);
    qDebug() << "Employee ID: " << id << " Status: " << ok;  // Debug output
    if (!ok || id.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Employee ID cannot be empty.");
        return;
    }

    QString name = QInputDialog::getText(this, "Employee Name", "Enter Employee Name:", QLineEdit::Normal, "", &ok);
    qDebug() << "Employee Name: " << name << " Status: " << ok;
    if (!ok || name.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Employee Name cannot be empty.");
        return;
    }

    QString department = QInputDialog::getText(this, "Department", "Enter Department:", QLineEdit::Normal, "", &ok);
    qDebug() << "Department: " << department << " Status: " << ok;
    if (!ok || department.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Department cannot be empty.");
        return;
    }

    QString task = QInputDialog::getText(this, "Assigned Task", "Enter Assigned Task:", QLineEdit::Normal, "", &ok);
    qDebug() << "Assigned Task: " << task << " Status: " << ok;
    if (!ok || task.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Assigned Task cannot be empty.");
        return;
    }

    QString status = QInputDialog::getText(this, "Task Status", "Enter Task Status:", QLineEdit::Normal, "", &ok);
    qDebug() << "Task Status: " << status << " Status: " << ok;
    if (!ok || status.trimmed().isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Task Status cannot be empty.");
        return;
    }

    // Append the validated data to the model
    QList<QStandardItem *> newRow;
    newRow.append(new QStandardItem(id.trimmed()));
    newRow.append(new QStandardItem(name.trimmed()));
    newRow.append(new QStandardItem(department.trimmed()));
    newRow.append(new QStandardItem(task.trimmed()));
    newRow.append(new QStandardItem(status.trimmed()));

    model->appendRow(newRow);  // Add the new row to the table
    qDebug() << "Employee successfully added!";
}

void ceopage::onUpdateTaskClicked() {
    // Example: Update the task details of the selected employee
    QModelIndex index = ui->tableViewEmployeeRecords->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Employee Selected", "Please select an employee to update.");
        return;
    }

    QString task = QInputDialog::getText(this, "Update Task", "Enter new task for the employee:",
                                         QLineEdit::Normal, "", nullptr);
    if (!task.isEmpty()) {
        model->setData(model->index(index.row(), 3), task);  // Assuming task is in the 4th column
    }
}

void ceopage::onViewReportsClicked() {
    // Example: Display reports related to the selected employee or task
    QModelIndex index = ui->tableViewEmployeeRecords->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Employee Selected", "Please select an employee to view reports.");
        return;
    }

    // You can implement the logic to view reports here
    QMessageBox::information(this, "View Reports", "Displaying reports for employee: " +
                                                       model->data(model->index(index.row(), 1)).toString());
}

// Updated in onViewTaskClicked function: Enhanced task detail display
void ceopage::onViewTaskClicked_2() { //repeated
    QModelIndex index = ui->tableViewEmployeeRecords_2->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Employee Selected", "Please select an employee to view the task.");
        return;
    }

    QString employeeName = model->data(model->index(index.row(), 1)).toString();
    QString task = model->data(model->index(index.row(), 3)).toString();  // Task is in the 4th column
    QString deadline = model->data(model->index(index.row(), 4)).toString();  // Deadline in the 5th column

    QMessageBox::information(this, "Task Details",
                             "Employee: " + employeeName +
                                 "\nTask: " + (task.isEmpty() ? "No Task Assigned" : task) +
                                 "\nDeadline: " + (deadline.isEmpty() ? "No Deadline Set" : deadline));
}
void ceopage::populateSampleData() {
    // Implementation for populating sample data
}

void ceopage::onMarkTaskCompleteClicked() {
    // Implementation for marking tasks as complete
}

void ceopage::onEditEmployeeDetailsClicked() {
    // Implementation for editing employee details
}

void ceopage::onExportDataClicked() {
    // Implementation for exporting data
}

void ceopage::onAddHeadClicked() {
    // Collect data for the new head
    bool ok;
    QString name = QInputDialog::getText(this, "Add Head", "Enter Name:", QLineEdit::Normal, "", &ok);
    if (!ok || name.isEmpty()) return;

    QString id = QInputDialog::getText(this, "Add Head", "Enter ID:", QLineEdit::Normal, "", &ok);
    if (!ok || id.isEmpty()) return;

    QString department = QInputDialog::getText(this, "Add Head", "Enter Department:", QLineEdit::Normal, "", &ok);
    if (!ok || department.isEmpty()) return;

    QString status = QInputDialog::getText(this, "Add Head", "Enter Status:", QLineEdit::Normal, "", &ok);
    if (!ok || status.isEmpty()) return;

    QString task = QInputDialog::getText(this, "Add Head", "Enter Task:", QLineEdit::Normal, "", &ok);
    if (!ok || task.isEmpty()) return;

    // Add new row to the model
    QList<QStandardItem*> newRow;
    newRow.append(new QStandardItem(name));
    newRow.append(new QStandardItem(id));
    newRow.append(new QStandardItem(department));
    newRow.append(new QStandardItem(status));
    newRow.append(new QStandardItem(task));

    headModel->appendRow(newRow); // Append the row to the model

    // Save to binary file
    saveHeadsToFile();
}

void ceopage::onRemoveHeadClicked() {
    // Get the selected row
    QModelIndex index = ui->HEADADDtableView->selectionModel()->currentIndex();
    if (!index.isValid()) {
        QMessageBox::warning(this, "No Head Selected", "Please select a head to remove.");
        return;
    }

    // Confirm deletion
    QMessageBox::StandardButton reply = QMessageBox::question(this, "Remove Head",
                                                              "Are you sure you want to remove the selected head?", QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        headModel->removeRow(index.row()); // Remove the selected row
        saveHeadsToFile(); // Save updated list to file
    }
}
// Function to initialize the HEADADDtableView
void ceopage::initializeHEADADDtableView()
{
    // Initialize the model for the HEADADDtableView
    headModel = new QStandardItemModel(this);
    headModel->setColumnCount(5);
    headModel->setHeaderData(0, Qt::Horizontal, "Name");
    headModel->setHeaderData(1, Qt::Horizontal, "ID");
    headModel->setHeaderData(2, Qt::Horizontal, "Department");
    headModel->setHeaderData(3, Qt::Horizontal, "Status");
    headModel->setHeaderData(4, Qt::Horizontal, "Task");

    // Set the model to the table view
    ui->HEADADDtableView->setModel(headModel);

    // Configure table view selection behavior
    ui->HEADADDtableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->HEADADDtableView->setSelectionMode(QAbstractItemView::SingleSelection);

    // Set custom column widths
    ui->HEADADDtableView->setColumnWidth(0, 145); // Width for "Name" column
    ui->HEADADDtableView->setColumnWidth(1, 145); // Width for "ID" column
    ui->HEADADDtableView->setColumnWidth(2, 145); // Width for "Department" column
    ui->HEADADDtableView->setColumnWidth(3, 145);  // Width for "Status" column
    ui->HEADADDtableView->setColumnWidth(4, 145); // Width for "Task" column

    // Additional optional configuration for the table view
    ui->HEADADDtableView->horizontalHeader()->setStretchLastSection(false);
    // ui->HEADADDtableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->HEADADDtableView->verticalHeader()->setVisible(false);
}

void ceopage::on_pushButtonLogin_2_clicked()
{
    this->close();
}


void ceopage::saveEmployeesToFile() {
    std::ofstream outFile("employees.dat", std::ios::binary);
    if (!outFile) {
        QMessageBox::warning(this, "File Error", "Unable to open file for saving employee data.");
        return;
    }

    int rowCount = model->rowCount();
    for (int row = 0; row < rowCount; ++row) {
        Employee employee;
        employee.id = model->data(model->index(row, 0)).toString();
        employee.name = model->data(model->index(row, 1)).toString();
        employee.department = model->data(model->index(row, 2)).toString();
        employee.task = model->data(model->index(row, 3)).toString();
        employee.status = model->data(model->index(row, 4)).toString();

        employee.writeToFile(outFile);  // Serialize employee data to the file
    }

    outFile.close();
}


void ceopage::loadEmployeesFromFile() {
    std::ifstream inFile("employees.dat", std::ios::binary);
    if (!inFile) {
        QMessageBox::warning(this, "File Error", "Unable to open file for loading employee data.");
        return;
    }

    while (inFile.peek() != EOF) {
        Employee employee;
        employee.readFromFile(inFile);  // Deserialize employee data from the file

        QList<QStandardItem *> newRow;
        newRow.append(new QStandardItem(employee.id));
        newRow.append(new QStandardItem(employee.name));
        newRow.append(new QStandardItem(employee.department));
        newRow.append(new QStandardItem(employee.task));
        newRow.append(new QStandardItem(employee.status));

        model->appendRow(newRow);  // Add the employee data to the table model
    }

    inFile.close();
}


// void ceopage::saveHeadsToFile() {
//     std::ofstream outFile("heads.dat", std::ios::binary);
//     if (!outFile) {
//         QMessageBox::warning(this, "File Error", "Unable to open file for saving head data.");
//         return;
//     }

//     int rowCount = headModel->rowCount();
//     for (int row = 0; row < rowCount; ++row) {
//         Head head;
//         head.name = headModel->data(headModel->index(row, 0)).toString();
//         head.id = headModel->data(headModel->index(row, 1)).toString();
//         head.department = headModel->data(headModel->index(row, 2)).toString();
//         head.status = headModel->data(headModel->index(row, 3)).toString();
//         head.task = headModel->data(headModel->index(row, 4)).toString();

//         head.writeHeadToFile(outFile);  // Serialize head data to the file
//     }

//     outFile.close();
// }
void ceopage::saveHeadsToFile() {
    std::ofstream outFile("heads.dat", std::ios::binary);
    if (!outFile) {
        QMessageBox::warning(this, "File Error", "Unable to open file for saving head data.");
        return;
    }

    int rowCount = headModel->rowCount();
    for (int row = 0; row < rowCount; ++row) {
        Head head;
        head.name = headModel->data(headModel->index(row, 0)).toString();
        head.id = headModel->data(headModel->index(row, 1)).toString();
        head.department = headModel->data(headModel->index(row, 2)).toString();
        head.status = headModel->data(headModel->index(row, 3)).toString();
        head.task = headModel->data(headModel->index(row, 4)).toString();

        head.writeToFile(outFile);  // Use writeToFile instead of writeHeadToFile
    }

    outFile.close();
}
// void ceopage::loadHeadsFromFile() {
//     std::ifstream inFile("heads.dat", std::ios::binary);
//     if (!inFile) {
//         QMessageBox::warning(this, "File Error", "Unable to open file for loading head data.");
//         return;
//     }

//     while (inFile.peek() != EOF) {
//         Head head;
//         head.readHeadFromFile(inFile);  // Deserialize head data from the file

//         QList<QStandardItem *> newRow;
//         newRow.append(new QStandardItem(head.name));
//         newRow.append(new QStandardItem(head.id));
//         newRow.append(new QStandardItem(head.department));
//         newRow.append(new QStandardItem(head.status));
//         newRow.append(new QStandardItem(head.task));

//         headModel->appendRow(newRow);  // Add the head data to the table model
//     }

//     inFile.close();
// }
void ceopage::loadHeadsFromFile() {
    std::ifstream inFile("heads.dat", std::ios::binary);
    if (!inFile) {
        QMessageBox::warning(this, "File Error", "Unable to open file for loading head data.");
        return;
    }

    while (inFile.peek() != EOF) {
        Head head;
        head.readFromFile(inFile);  // Use readFromFile instead of readHeadFromFile

        QList<QStandardItem *> newRow;
        newRow.append(new QStandardItem(head.name));
        newRow.append(new QStandardItem(head.id));
        newRow.append(new QStandardItem(head.department));
        newRow.append(new QStandardItem(head.status));
        newRow.append(new QStandardItem(head.task));

        headModel->appendRow(newRow);  // Add the head data to the table model
    }

    inFile.close();
}

