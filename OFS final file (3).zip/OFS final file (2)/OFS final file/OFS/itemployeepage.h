#ifndef ITEMEMPLOYPAGE_H
#define ITEMEMPLOYPAGE_H

#include <QWidget>
#include "itememployeemodel.h"

namespace Ui {
class itemEmployeepage;
}

class itemEmployeepage : public QWidget
{
    Q_OBJECT

public:
    explicit itemEmployeepage(QWidget *parent = nullptr);
    ~itemEmployeepage();

private slots:
    // Slot to handle the button click for submitting tasks
    void on_submitTaskButton_clicked();

private:
    Ui::itemEmployeepage *ui;

    ItemEmployeeModel *employeeModel;  // Model to handle employee data
};

#endif // ITEMEMPLOYPAGE_H
