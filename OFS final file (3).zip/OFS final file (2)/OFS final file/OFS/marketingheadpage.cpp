#include "marketingheadpage.h"
#include "ui_marketingheadpage.h"
#include <QStandardItemModel>
#include <QInputDialog>
#include <QMessageBox>
#include <QFile>
#include <QDataStream>

marketingheadpage::marketingheadpage(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::marketingheadpage)
{
    ui->setupUi(this);
    ui->setupUi(this);

    // Initialize table view and set model
    employeeTable = ui->marketingheadpagecoffeetable;  // Assuming you have this table in your UI (.ui file)
    model = new QStandardItemModel(0, 4, this);  // 4 columns (Name, Department, ID, Task)
    employeeTable->setModel(model);

    // Set column headers
    model->setHorizontalHeaderLabels({"Name", "Department", "ID", "Task"});

    rowCount = 0;

    // Adjust column widths
    adjustTableColumns();

    // Connect buttons to their corresponding slots
    connect(ui->hiringofmarketingemployee_pushbutton_2, &QPushButton::clicked, this, &marketingheadpage::onAddEmployeeClicked);
    connect(ui->firingofmarketingemployee_pushbutton_2, &QPushButton::clicked, this, &marketingheadpage::onRemoveEmployeeClicked);
    connect(ui->assigningtasktomarketingemployee_pushbutton_2, &QPushButton::clicked, this, &marketingheadpage::onAssignTaskClicked);
    connect(ui->checkingtaskofmarketingemployee_pushbutton_2, &QPushButton::clicked, this, &marketingheadpage::onViewTaskClicked);

    employeeTable->setSelectionMode(QAbstractItemView::SingleSelection);
    employeeTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    // Load saved employee data from the binary file
    loadEmployeeData();
}

marketingheadpage::~marketingheadpage()
{
    // Save data before closing
    saveEmployeeData();
    delete ui;
}
// Slot for adding a new employee
void marketingheadpage::onAddEmployeeClicked()
{
    bool ok;
    QString name = QInputDialog::getText(this, "Add Employee", "Enter employee name:", QLineEdit::Normal, "", &ok);
    if (ok && !name.isEmpty()) {
        QString department = QInputDialog::getText(this, "Add Employee", "Enter employee department:", QLineEdit::Normal, "", &ok);
        if (ok && !department.isEmpty()) {
            int id = QInputDialog::getInt(this, "Add Employee", "Enter employee ID:", 0, 0, 100000, 1, &ok);
            if (ok) {
                // Add the employee to the model
                QList<QStandardItem *> items;
                items.append(new QStandardItem(name));
                items.append(new QStandardItem(department));
                items.append(new QStandardItem(QString::number(id)));
                items.append(new QStandardItem(""));  // Empty task for new employee

                model->appendRow(items);
                rowCount++;
            }
        }
    }
}
// Slot for removing an employee
void marketingheadpage::onRemoveEmployeeClicked()
{
    QItemSelectionModel *select = employeeTable->selectionModel();
    QModelIndexList selectedRows = select->selectedRows();

    if (!selectedRows.isEmpty()) {
        for (const QModelIndex &index : selectedRows) {
            model->removeRow(index.row());
        }
        rowCount--;
    } else {
        QMessageBox::warning(this, "Error", "Please select an employee to fire.");
    }
}
// Slot for assigning a task to an employee
void marketingheadpage::onAssignTaskClicked()
{
    QItemSelectionModel *select = employeeTable->selectionModel();
    QModelIndexList selectedRows = select->selectedRows();

    if (!selectedRows.isEmpty()) {
        bool ok;
        QString task = QInputDialog::getText(this, "Assign Task", "Enter task for the selected employee:", QLineEdit::Normal, "", &ok);
        if (ok && !task.isEmpty()) {
            // Assign task in the last column (Task column)
            int row = selectedRows.first().row();
            model->setData(model->index(row, 3), task);  // Set task in the fourth column
        }
    } else {
        QMessageBox::warning(this, "Error", "Please select an employee to assign a task.");
    }
}
// Slot for viewing an employee's task
void marketingheadpage::onViewTaskClicked()
{
    QItemSelectionModel *select = employeeTable->selectionModel();
    QModelIndexList selectedRows = select->selectedRows();

    if (!selectedRows.isEmpty()) {
        int row = selectedRows.first().row();
        QString task = model->data(model->index(row, 3)).toString();
        task = task.isEmpty() ? "No task assigned" : task;
        QMessageBox::information(this, "Employee Task", "Task: " + task);
    } else {
        QMessageBox::warning(this, "Error", "Please select an employee to view the task.");
    }
}
// Helper function to initialize the table columns
void marketingheadpage::adjustTableColumns()
{
    employeeTable->setColumnWidth(0, 180);  // Set width of Name column
    employeeTable->setColumnWidth(1, 180);  // Set width of Department column
    employeeTable->setColumnWidth(2, 180);  // Set width of ID column
    employeeTable->setColumnWidth(3, 180);  // Set width of Task column
}
// Save employee data to a binary file
void marketingheadpage::saveEmployeeData()
{
    QFile file("smurfs.dat");
    if (file.open(QIODevice::WriteOnly)) {
        QDataStream out(&file);
        out << rowCount;  // Store the number of employees

        for (int i = 0; i < rowCount; ++i) {
            QString name = model->data(model->index(i, 0)).toString();
            QString department = model->data(model->index(i, 1)).toString();
            int id = model->data(model->index(i, 2)).toInt();
            QString task = model->data(model->index(i, 3)).toString();
            out << name << department << id << task;
        }
        file.close();
    } else {
        QMessageBox::warning(this, "Error", "Failed to save employee data.");
    }
}
// Load employee data from a binary file
void marketingheadpage::loadEmployeeData()
{
    QFile file("smurfs.dat");
    if (file.open(QIODevice::ReadOnly)) {
        QDataStream in(&file);
        int employeeCount;
        in >> employeeCount;  // Read the number of employees
        rowCount = employeeCount;  // Set rowCount to the number of employees

        for (int i = 0; i < employeeCount; ++i) {
            QString name, department, task;
            int id;
            in >> name >> department >> id >> task;
            QList<QStandardItem *> items;
            items.append(new QStandardItem(name));
            items.append(new QStandardItem(department));
            items.append(new QStandardItem(QString::number(id)));
            items.append(new QStandardItem(task));

            model->appendRow(items);
        }
        file.close();
    } else {
        QMessageBox::warning(this, "Error", "Failed to load employee data.");
    }
}



void marketingheadpage::on_pushButtonLogin_2_clicked()
{
    this->close();
}

