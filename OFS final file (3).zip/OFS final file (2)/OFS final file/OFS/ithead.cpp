#include "ithead.h"

ITHead::ITHead() {}
