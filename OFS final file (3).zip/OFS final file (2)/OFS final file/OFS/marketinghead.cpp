#include "marketinghead.h"

marketingHead::marketingHead() {}
