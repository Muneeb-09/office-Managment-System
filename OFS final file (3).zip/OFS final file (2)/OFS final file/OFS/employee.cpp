#include "employee.h"
#include <fstream>
#include <vector>
#include <iostream>  // Required for std::cout and std::cerr

// Add Employee to File
void addEmployee(const employee& emp) {
    std::ofstream outFile("employees.dat", std::ios::binary | std::ios::app);
    if (outFile.is_open()) {
        outFile.write(reinterpret_cast<const char*>(&emp), sizeof(employee));
        std::cout << "Employee added: ID=" << emp.id << " Name=" << emp.name << std::endl;
    } else {
        std::cerr << "Failed to open file for writing!" << std::endl;
    }

    outFile.close();
}


// Remove Employee from File
void removeEmployee(int empId) {
    std::ifstream inFile("employees.dat", std::ios::binary);
    std::ofstream tempFile("temp.dat", std::ios::binary);

    employee emp;
    while (inFile.read(reinterpret_cast<char*>(&emp), sizeof(employee))) {
        if (emp.id != empId) {
            tempFile.write(reinterpret_cast<const char*>(&emp), sizeof(employee));
        }
    }

    inFile.close();
    tempFile.close();

    std::remove("employees.dat");
    std::rename("temp.dat", "employees.dat");
}

// Fetch All Employees
std::vector<employee> fetchAllEmployees() {
    std::vector<employee> employees;
    std::ifstream inFile("employees.dat", std::ios::binary);

    employee emp;
    while (inFile.read(reinterpret_cast<char*>(&emp), sizeof(employee))) {
        employees.push_back(emp);
    }

    inFile.close();
    return employees;
}
