#ifndef CEO1_H
#define CEO1_H

class CEO1
{
public:
    CEO1();
};

#endif // CEO1_H
