#include "ceo1.h"

CEO1::CEO1() {}
