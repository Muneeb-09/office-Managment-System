#include "itemployeepage.h"
#include "ui_itemployeepage.h"
#include "taskassignmentdialog.h"  // Include task assignment dialog (you will create this if not already done)

itemEmployeepage::itemEmployeepage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::itemEmployeepage)
{
    ui->setupUi(this);

    // Create the model and set it to the table view
    employeeModel = new ItemEmployeeModel(this);
    ui->displayofitemployeetableView->setModel(employeeModel);

    // Load data into the model (it's done automatically in ItemEmployeeModel constructor)
    employeeModel->loadDataFromFile();
}

itemEmployeepage::~itemEmployeepage()
{
    delete ui;
}

void itemEmployeepage::on_submitTaskButton_clicked()
{
    // Open the Task Assignment dialog when the button is clicked
    TaskAssignmentDialog taskDialog;
    if (taskDialog.exec() == QDialog::Accepted) {
        // Handle task assignment logic here, if needed
    }
}
